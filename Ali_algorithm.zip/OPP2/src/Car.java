public class Car {

	String make = "Burger";
	String model = "Hotdog";
	int year = 2020;
	String color = "blue";
	double price = 50000.00;
	
	void drive() {
		System.out.println("I like both");
	}
	void brake() {
		System.out.println("Specially when I'm hungry");
	}	
}