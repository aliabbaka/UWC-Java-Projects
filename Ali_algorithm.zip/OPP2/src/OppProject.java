public class OppProject {

	public static void main(String[] args) {
		
		Car myCarone = new Car();
		Car myCartwo = new Car();
		System.out.println(myCarone.make);
		System.out.println(myCartwo.model);
		myCarone.drive();
		myCarone.brake();
		
	}
}