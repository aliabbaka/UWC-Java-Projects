public class Apple {

	public static void main(String[] args) {
		
		Human human2 = new Human("Rick",65,70);
		Human human1 = new Human("Morty",16,50);
			
		human2.drink();
		human1.eat();
		
	}
}