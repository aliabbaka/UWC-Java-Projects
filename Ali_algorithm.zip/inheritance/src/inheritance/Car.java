package inheritance;

public class Car extends Vehicle{
int wheels = 4;
int door = 4;
public char[] doors;
}