package classWork;

public class Dog {
 String name; 
 String colour;
 String breed;
 
 void bark() {
	 System.out.print("woof");
 }
 void sleep() {
	 System.out.print("Zzzz");
 }
 void wagTall() {
	 System.out.print("<Wagging>");
 }
}
