package classWork;

public class Driver {
 public static void main (String[] args) {
	 System.out.print("being woriking");
 
 
	Dog d = new Dog();

	d.breed = "ali";
 }
}
