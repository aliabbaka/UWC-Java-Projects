import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.HashMap;
import java.util.Map.Entry;


public class TextEditor extends JFrame implements ActionListener {
	// Implementing the program
	JPanel headerM = new JPanel(new FlowLayout());
	
    JTextArea txtBox;
    JScrollPane scrollPane;
    JLabel fontType;
     JSpinner fonttSize;
      JButton fontColour;
JComboBox typeBox;
    JButton backgroundColor; 
 JLabel Counter; 
  JMenuBar menuBar;
   JMenu fileM;
   JMenuItem Help;
JMenuItem openFile;
    JMenuItem saveFile;
JMenuItem exitFile;
    JComboBox<String> sortOptions; 
  JMenu darkMode;

    public TextEditor() {

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Text Processor ");
       this.setSize(500, 500);
        this.setLayout(new FlowLayout());
        this.setLocationRelativeTo(null);
        txtBox = new JTextArea();
        txtBox.setLineWrap(true);
      txtBox.setWrapStyleWord(true);
        txtBox.setFont(new Font("Arial", Font.PLAIN, 20));
     
        scrollPane = new JScrollPane(txtBox);
        scrollPane.setPreferredSize(new Dimension(450, 400));
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        fontType = new JLabel("Font size: ");

        fonttSize = new JSpinner();
      fonttSize.setPreferredSize(new Dimension(50, 25));
        fonttSize.setValue(20);
        fonttSize.addChangeListener(new ChangeListener() {
    
        	
            @Override
            public void stateChanged(ChangeEvent e) {
            	 // it loads a text box with consideration of font 
                //size and type and keep it ready to change anytime 
                    	//the user change it's settings
                txtBox.setFont(new Font(txtBox.getFont().getFamily(), Font.PLAIN, (int) fonttSize.getValue()));
            }

        });
        //the display of buttons and the changing interaction  
        fontColour = new JButton("Font Color");
        fontColour.addActionListener(this);
        backgroundColor = new JButton("Background Color"); 
       backgroundColor.addActionListener(this); 

       
        String[] fontTypes = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();

       typeBox = new JComboBox(fontTypes);
       
        typeBox.addActionListener(this);
        
       typeBox.setSelectedItem("Arial"); //default text type 
       
        Counter = new JLabel("Word count: 0");
        
        
        JPanel headerM = new JPanel();// what will be displayed inside the program from functions and text box 
       
        headerM.add(fontType);
        
       headerM.setLayout(new BoxLayout(headerM, BoxLayout.Y_AXIS));//this indicates they should be one next to each other when screen gets bigger
      headerM.add(fontColour);
       
       headerM.add(backgroundColor);
      
       headerM.add(fonttSize);                    
      headerM.add(fontColour);
       
       headerM.add(backgroundColor);
      
        headerM.add(typeBox);
        
     headerM.add(Counter); 
     
     
        // Sorting algorithm Implementation 
        String[] sortOptionsArray = {"Alphabetically"};
        
        txtBox.getDocument().addDocumentListener(new DocumentListener() {//Implementation the detector of word count functional:   
            public void changedUpdate(DocumentEvent e) { 
                updateWordCount(); //when updating the text
            }

            public void insertUpdate(DocumentEvent e) {
                updateWordCount();  //when insert the text
            }

            public void removeUpdate(DocumentEvent e) {
                updateWordCount();  //when remove the text
            }
        });

        JButton sortOccurrenceButton = new JButton("Sort by Occurrence");
        sortOccurrenceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortByOccurrence();
            }
        });
        headerM.add(sortOccurrenceButton);

        
        // header and all the options of navigation bar that should be presented
        menuBar = new JMenuBar();
        fileM = new JMenu("File");
        openFile = new JMenuItem("Open");
        saveFile = new JMenuItem("Save");
        exitFile = new JMenuItem("Exit");
        openFile.addActionListener(this);
        saveFile.addActionListener(this);
        exitFile.addActionListener(this);
        fileM.add(openFile);
        fileM.add(saveFile);
        fileM.add(exitFile);
        menuBar.add(fileM);
        menuBar.add(Counter);
        Help = new JMenuItem("Help");
        Help.addActionListener(this);
        menuBar.add(Help, 1);
        darkMode = new JMenu("Dark Mode");
        JMenuItem darkModeItem = new JMenuItem("Click to Confirm");
        darkModeItem.addActionListener(new ActionListener() { //the confirmation button for dark mode on/off
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleDarkMode();
            }
        });
        darkMode.add(darkModeItem);
        menuBar.add(darkMode);
        JButton sortAlphabeticallyButton = new JButton("Sort Alphabetically");
        sortAlphabeticallyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sortByAlphabeticalOrder();
            }
        });
        headerM.add(sortAlphabeticallyButton); 
  //menu Bar

        this.setJMenuBar(menuBar);
        this.add(headerM);
        this.add(scrollPane); //making the text box with specific size and a scroller to go under when exceeding the limits 
        this.setVisible(true);
    }
  //the down one provide the constructor that contain a value added to the letter 
 // down we are using the string method that counts the words which is provide the displayed numbers
    private void sortByOccurrence() {
        // Create a map to store word occurrences
        Map<String, Integer> wordCountMap = new HashMap<>();
        String text = txtBox.getText().toLowerCase(); // Convert all text to "lowercase" for case-insensitive counting
        String[] words = text.split("\\s+");

        // Count occurrences of each word
        for (String word : words) {
            // Remove non-word characters from the word
            word = word.replaceAll("[^\\w]", "");

            if (wordCountMap.containsKey(word)) {
                wordCountMap.put(word, wordCountMap.get(word) + 1);
            } else {
                wordCountMap.put(word, 1);
            }
        }

        // Sort the entries based on the occurrence count
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(wordCountMap.entrySet());
        sortedEntries.sort((e1, e2) -> e2.getValue().compareTo(e1.getValue()));

        // Construct the sorted text
        StringBuilder sortedText = new StringBuilder();
        for (Map.Entry<String, Integer> entry : sortedEntries) {
            for (int i = 0; i < entry.getValue(); i++) {
                sortedText.append(entry.getKey()).append(" ");
            }
        }

        // Set the sorted text back to the text box
        txtBox.setText(sortedText.toString());
    }


    private void showHelpDialog() {
        String notes = " *notes and instructions on how this program: \n file controls where the text can be saved or which one to open or exit with closing the program fontType size controls how big the size of the fontType\n"
                + " font color controls the color of the text\n"
                + " background color control the text field color\n"
                + " sort option can be sorted either options which is alphabetically, or by occurrence sorting into groups from the same word type\n"
           
                + "word count shows how many words have been written ";
        JOptionPane.showMessageDialog(null, notes, "Help", JOptionPane.INFORMATION_MESSAGE);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
    	
        if (e.getSource() == fontColour) {
            JColorChooser colorChooser = new JColorChooser();
            Color color = colorChooser.showDialog(null, "Choose a color", Color.black);
            txtBox.setForeground(color);
        }
        if (e.getSource() == backgroundColor) { 
            JColorChooser colorChooser = new JColorChooser();
            Color color = colorChooser.showDialog(null, "Choose a color", Color.white);
            txtBox.setBackground(color);
        }
        if (e.getSource() == typeBox) {
            txtBox.setFont(new Font((String) typeBox.getSelectedItem(), Font.PLAIN, txtBox.getFont().getSize()));
        }
        
        if (e.getSource() == openFile) {
           JFileChooser fileChooser = new JFileChooser();
            fileChooser.setCurrentDirectory(new File("."));
          FileNameExtensionFilter filter = new FileNameExtensionFilter("Text files", "txt");
            fileChooser.setFileFilter(filter);
            int response = fileChooser.showOpenDialog(null);
            if (response == JFileChooser.APPROVE_OPTION) {
                File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
              Scanner fileIn = null;
                try {
                    fileIn = new Scanner(file);
                    if (file.isFile()) {
                     while (fileIn.hasNextLine()) {
                            String line = fileIn.nextLine() + "\n";
                            txtBox.append(line);
                        }
                    }
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
               } finally {
                    fileIn.close();
             }
            }
        } 
        if (e.getSource() == saveFile) {// when the save file is clicked it will open a window asking where to be saved 
            JFileChooser fileChooser = new JFileChooser();// then save a txt file and giving a respond of 
            fileChooser.setCurrentDirectory(new File(".")); //Mission completed successfully
          int response = fileChooser.showSaveDialog(null);
            if (response == JFileChooser.APPROVE_OPTION) {
             File file;
                PrintWriter fileOut = null;
                file = new File(fileChooser.getSelectedFile().getAbsolutePath());
               try {
                    fileOut = new PrintWriter(file);
                    fileOut.println(txtBox.getText());
                } catch (FileNotFoundException e1) {
                    e1.printStackTrace();
                } finally {
                    fileOut.close();
                }
            }
        }
        if (e.getSource() == exitFile) { // when the exit file is clicked the condition will be
            System.exit(0);     // true and 0 indicate a completed termination closing the program after
        }
    
        
        // Sorting 


        if (e.getSource() == Help) {
            showHelpDialog();
        }} 
    private void sortByAlphabeticalOrder() {
        ArrayList<String> lines = new ArrayList<>(Arrays.asList(txtBox.getText().split("\n")));
        Collections.sort(lines);
        StringBuilder sortedText = new StringBuilder();
        for (String line : lines) {
            sortedText.append(line).append("\n");
        }
        txtBox.setText(sortedText.toString());
    }
//here is how should the dark mode work
    private void toggleDarkMode() {
        Color backgroundColor = txtBox.getBackground();
      Color fontColour = txtBox.getForeground();

        if (backgroundColor.equals(Color.WHITE)) { //when choosing the dark mode to deactivate it change the backgroundColor to white and text to black
            txtBox.setBackground(Color.BLACK);
            txtBox.setForeground(Color.WHITE); 
        } else { //when choosing the dark mode to activate it change the backgroundColor to white and text to black
          txtBox.setBackground(Color.WHITE);
            txtBox.setForeground(Color.BLACK);
        }
    }  
    private void updateWordCount() { //it calculate number of words according to the number of separated words 
        String text = txtBox.getText();
      String[] words = text.trim().split("\\s+");
        int wordCount = words.length; 
    Counter.setText("Word count: " + wordCount);
    }
    public static void main(String[] args) { 
      new TextEditor();
    }
}