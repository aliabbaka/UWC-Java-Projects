public class Car {

	String make = "I love the cars specially";
	String model = "Corvette";
	int year = 2020;
	String color = "blue";
	double price = 50000.00;
	
	void drive() {
		System.out.println("driving fast is the best");
	}
	void brake() {
		System.out.println("and it goes the opposite with the breaks");
	}	
}