public class ArrayProj {
 public static void main(String[] args) {
	                                  // array = it is used to store multiple values within a single variable
	String[] cars = new String[3]; 	 //the variable "cars" string equal to new data consists of 3 elements
		
	cars[0] = "Camaro";
	cars[1] = "Corvette";
	cars[2] = "Tesla";
			
 for(int i=0; i<cars.length; i++) {
 System.out.println(cars[i]);
		}
	
	}
}