package arithmeticExpressions;


public class Hi {

 public static void main(String[] args) {
  
  // expression =     operands & operators
  // operands =  values, variables, numbers, quantity
  // operators = + - * / % 

	 int friends = 18;
	 friends = friends * 2 / 2 - 4 + 1 ;
	 System.out.println(friends);
	 
	 
 } 
}